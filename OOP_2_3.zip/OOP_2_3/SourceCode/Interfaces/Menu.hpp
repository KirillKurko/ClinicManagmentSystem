#ifndef Menu_hpp
#define Menu_hpp

#include "CreateFunctions.hpp"

int mainMenu();

void viewMenu();

void viewDoctors();
void viewParamedics();
void viewDentist();
void viewNurses();
void viewPatients();

void add();
void remove();
void task();

#endif 
