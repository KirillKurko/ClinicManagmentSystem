#include "SourceCode/Interfaces/Menu.hpp"

using namespace std;

int main() {
	while (mainMenu()) {};
	return 0;
}


